from visual import Plot

def insertionSort(data):
    for i in range(1, len(data)):
        key = data[i]
        j = i - 1
        while j >= 0 and key < data[j]:
            data[j + 1] = data[j]
            j -= 1
            print("sorting insertion sort..... ", j)
            Plot(j + 1, data)
        data[j + 1] = key
        Plot(j + 1, data)
