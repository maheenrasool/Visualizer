import matplotlib.pyplot as plt
from celluloid import Camera
import matplotlib
matplotlib.use('Agg')  # backend for non-interactive plotting

fig, ax = plt.subplots()
camera = Camera(fig)
comparisons = 0

titles = {
    '1': "Bubblesort algorithm",
    '2': 'Insertion algorithm',
    '3': 'Selection algorithm',
    '4': 'Merge algorithm', 
    '5': 'Quick algorithm', 
    '6': 'Heap algorithm', 
    '7': 'Radix algorithm', 
    '8': 'Bucket algorithm', 
    '9': 'Count algorithm' 
}


def alg_title(alg):
    global title
    title = titles[alg]
    return title



def Plot(highlight, data):
    x = list(range(len(data)))
    global comparisons
    comparisons += 1

    # background colors
    fig.patch.set_facecolor('black')  # Black figure background
    ax.set_facecolor('black')         # Black axis background

    # bar colors, magenta for one being swapped
    colors = ['white'] * len(data) # color all bars white
    colors[highlight] = 'magenta' # only color this bar magenta


    ax.bar(x, data, color=colors)

    ax.set_title(title, color='white')
    ax.set_xlabel(f'Data size:{len(data)}, Comparisons:{comparisons}', color='white')

    ax.tick_params(axis='both', colors='white')

    camera.snap()  # save current frame

