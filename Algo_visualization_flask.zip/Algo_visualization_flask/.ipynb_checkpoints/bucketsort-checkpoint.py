from visual import Plot

def bucketSort(data):
    bucket = []
    for i in range(len(data)):
        bucket.append([])

    for j in data:
        index = int(10 * j)
        bucket[index].append(j)
        print("bucketing..... ", j)
        Plot(j, data)

    for i in range(len(data)):
        bucket[i] = sorted(bucket[i])

    k = 0
    for i in range(len(data)):
        for j in range(len(bucket[i])):
            data[k] = bucket[i][j]
            k += 1
            Plot(k, data)
