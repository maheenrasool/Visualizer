from visual import Plot

def countradix(data, exp):
    n = len(data)
    output = [0] * n
    count = [0] * 10

    for i in range(n):
        index = data[i] // exp
        count[index % 10] += 1
        print("counting..... ", data[i])
        Plot(data[i], data)

    for i in range(1, 10):
        count[i] += count[i - 1]

    i = n - 1
    while i >= 0:
        index = data[i] // exp
        output[count[index % 10] - 1] = data[i]
        count[index % 10] -= 1
        print("placing..... ", data[i])
        Plot(data[i], data)
        i -= 1

    for i in range(n):
        data[i] = output[i]

def radixSort(data):
    max_val = max(data)
    exp = 1
    while max_val // exp > 0:
        countradix(data, exp)
        exp *= 10
