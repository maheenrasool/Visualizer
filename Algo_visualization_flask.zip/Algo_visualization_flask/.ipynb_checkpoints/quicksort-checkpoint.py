from visual import Plot

def partition(data, start, end):
    b = (start - 1)  # border
    pivot = data[end]  # pivot

    for i in range(start, end):
        # Swap current element with border value if current element is smaller than or equal to pivot
        if data[i] <= pivot:
            b += 1
            data[b], data[i] = data[i], data[b]

            # Plot pivot and data set
            Plot(pivot, data)
            print("sorting....")
    # Swap pivot with border value
    data[b + 1], data[end] = data[end], data[b + 1]
    return b + 1


def quickSort(data, start, end):
    if start < end:
        # Return the pivot index
        p = partition(data, start, end)

        # Sort all the elements to the left and to the right of the pivot
        quickSort(data, start, p - 1)
        quickSort(data, p + 1, end)


# def partition(data, low, high):
#     pivot = data[high]
#     i = low - 1
#     for j in range(low, high):
#         if data[j] <= pivot:
#             i += 1
#             data[i], data[j] = data[j], data[i]
#             print("sorting..... ", j)
#             Plot(j, data)
#     data[i + 1], data[high] = data[high], data[i + 1]
#     Plot(i + 1, data)
#     return i + 1

# def quickSort(data):
#     size = len(data)
#     stack = [0] * (size)

#     top = -1
#     top += 1
#     stack[top] = 0
#     top += 1
#     stack[top] = size - 1

#     while top >= 0:
#         high = stack[top]
#         top -= 1
#         low = stack[top]
#         top -= 1

#         pi = partition(data, low, high)

#         if pi - 1 > low:
#             top += 1
#             stack[top] = low
#             top += 1
#             stack[top] = pi - 1

#         if pi + 1 < high:
#             top += 1
#             stack[top] = pi + 1
#             top += 1
#             stack[top] = high
