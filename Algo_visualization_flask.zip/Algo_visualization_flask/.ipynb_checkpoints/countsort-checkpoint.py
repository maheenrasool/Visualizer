from visual import Plot

def countSort(data):
    max_val = max(data)
    count = [0] * (max_val + 1)
    
    for num in data:
        count[num] += 1
        print("counting..... ", num)
        Plot(num, data)

    index = 0
    for i in range(len(count)):
        while count[i] > 0:
            data[index] = i
            count[i] -= 1
            print("placing..... ", index)
            Plot(index, data)
            index += 1
