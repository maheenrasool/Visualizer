# # Code made by WilliamHYZhang, source:https://github.com/TheAlgorithms/Python/blob/master/sorts/heap_sort.py
# from animate import Plot

# # To heapify subtree rooted at index i.
# # n is size of heap
# def heapify(unsorted, index, heap_size):
#     largest = index
#     left_index = 2 * index + 1
#     right_index = 2 * index + 2
#     if left_index < heap_size and unsorted[left_index] > unsorted[largest]:
#         largest = left_index

#     if right_index < heap_size and unsorted[right_index] > unsorted[largest]:
#         largest = right_index

#     if largest != index:
#         unsorted[largest], unsorted[index] = unsorted[index], unsorted[largest]
#         heapify(unsorted, largest, heap_size)
#         Plot(largest,unsorted)

# def heapSort(unsorted):

#     n = len(unsorted)
#     for i in range(n // 2 - 1, -1, -1):
#         heapify(unsorted, i, n)
#     for i in range(n - 1, 0, -1):
#         unsorted[0], unsorted[i] = unsorted[i], unsorted[0]
#         heapify(unsorted, 0, i)
#     return unsorted

from visual import Plot

def heapify(data, n, i):
    largest = i
    left = 2 * i + 1
    right = 2 * i + 2

    if left < n and data[i] < data[left]:
        largest = left

    if right < n and data[largest] < data[right]:
        largest = right

    if largest != i:
        data[i], data[largest] = data[largest], data[i]
        print("sorting..... ", i)
        Plot(i, data)
        heapify(data, n, largest)

def heapSort(data):
    n = len(data)

    for i in range(n // 2 - 1, -1, -1):
        heapify(data, n, i)

    for i in range(n - 1, 0, -1):
        data[i], data[0] = data[0], data[i]
        Plot(i, data)
        heapify(data, i, 0)
