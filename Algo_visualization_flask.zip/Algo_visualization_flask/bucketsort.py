from visual import Plot

def bucketSort(data):

    data_min = min(data)
    data_max = max(data)
    bucket = []
    for i in range(len(data)):
        bucket.append([])

    for j in data:
        norm_j = (j - data_min) / (data_max - data_min) 
        index = int(10 *  norm_j) # values may not all be float 
        bucket[index].append(j)
        print("bucketing..... ", j)
        Plot(index, data)

    for i in range(len(data)):
        bucket[i] = sorted(bucket[i])

    k = 0
    for i in range(len(data)):
        for j in range(len(bucket[i])):
            data[k] = bucket[i][j]
            Plot(k, data)
            k += 1
            
            
