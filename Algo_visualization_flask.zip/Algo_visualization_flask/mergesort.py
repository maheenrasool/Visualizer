from visual import Plot

def mergeSort(data):
    print("length of data: ", len(data))
    if len(data) > 1:
        mid = len(data) // 2
        L = data[:mid]
        R = data[mid:]

        mergeSort(L)
        mergeSort(R)

        i = j = k = 0
        while i < len(L) and j < len(R):
            if L[i] < R[j]:
                data[k] = L[i]
                i += 1
            else:
                data[k] = R[j]
                j += 1
            
            Plot(k, data) 
            print("merging..... ", k)
            k += 1 

        while i < len(L):
            data[k] = L[i]
            i += 1
            k += 1
            print("merging..... ", k)
            Plot(i, data) #Plot(k, data)

        while j < len(R):
            data[k] = R[j]
            j += 1
            k += 1
            print("merging..... ", k)
            Plot(j, data) #Plot(k, data)

# mergeSort([6,5,4,3,2,1])