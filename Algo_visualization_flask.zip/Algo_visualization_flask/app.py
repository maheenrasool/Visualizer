#Libraries/frameworks to be installed:
# https://www.wikihow.com/Install-FFmpeg-on-Windows
#celluloid : pip install celluloid        
#references: https://github.com/lucs123/sorting-visualizer-matplotlib
from flask import Flask, render_template, request, redirect, url_for
import random
import os
import time 
from visual import camera, alg_title
from bubblesort import bubbleSort  

# Not implemented sorting algorithms
from quicksort import quickSort
from heapsort import heapSort
from insertionsort import insertionSort
from selectionsort import selectionSort
from mergesort import mergeSort
from radixsort import radixSort
from bucketsort import bucketSort
from countsort import countSort

#issues are at MergeSort, BucketSort

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/visualize', methods=['POST'])
def visualize():
    data_size = int(request.form['data_size'])
    alg_choice = request.form['algorithm']
    arr = request.form['user_array']

    if arr:
        # Split the input string into an array of integers
        data = list(map(int, arr.split(',')))
        arr = data.copy()  # to send the original array back to the template
    else:
        # Generate a random array of the specified size
        data = random.sample(range(data_size), data_size)
        arr = data.copy()  # to send the original array back to the template

    # Generate random data(a random array)
    data.sort(reverse=True)

    algorithms = {
        '1': bubbleSort,
       '2': insertionSort,
      '3': selectionSort,
      '4': mergeSort,
        '5': quickSort,
        '6': heapSort,
        '7': radixSort,
      
        '8': bucketSort,
        '9': countSort,
    }

    func = algorithms.get(alg_choice)
    print("ALG CHOICE: ",alg_choice, "TYPE: ", type(alg_choice))

    if func:

        animation_path = os.path.join('static', 'visualization.mp4')
        if os.path.exists(animation_path): #delete previous video file
            os.remove(animation_path)
            time.sleep(2)
            print("Previous display video successfully removed")

        alg_title(alg_choice) 
        if func == bubbleSort:
            bubbleSort(data)  # sorting function
        elif func == insertionSort:
            insertionSort(data)
        elif func == selectionSort:
            selectionSort(data)
        elif func == mergeSort:
            mergeSort(data)
        elif func == quickSort:
            quickSort(data, 0, len(data)-1)
        elif func == heapSort:
            heapSort(data)
        elif func == radixSort:
            radixSort(data)
            print("sorted: ", data)
        elif func == bucketSort:
            bucketSort(data)
        elif func == countSort:
            countSort(data)

        
        interval_time = 25  # frame interval
        animation = camera.animate(interval=interval_time)

        # Save the video
        animation_path = os.path.join('static', 'visualization.mp4')
        animation.save(animation_path)

        return render_template('index.html', animation_path=animation_path, data_size = data_size, algorithm = alg_choice, user_array=', '.join(map(str, arr)) )
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)


